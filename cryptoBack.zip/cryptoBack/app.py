from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
import pickle

model = load_model("bitcoin_lstm_model.h5")
with open("scaler.pkl", "rb") as f:
    scaler = pickle.load(f)

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json.get('prices', [])
    print(data)

    predictions = []
    for _ in range(3):
        input_data = np.array(data).reshape(-1, 1)
        scaled_input = scaler.transform(input_data)
        X_test = np.reshape(scaled_input, (1, 60, 1))
        predicted_price = model.predict(X_test)
        predicted_price = scaler.inverse_transform(predicted_price)
        predictions.append(float(predicted_price[0][0]))
        data.append(predicted_price[0][0])
        data.pop(0)

    print(f"Predicted price: {predictions}")


    return jsonify(predictions)

if __name__ == '__main__':
    app.run(debug=True)
